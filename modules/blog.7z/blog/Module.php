<?php

namespace modules\blog;

class Module extends \common\lib\Module
{

}