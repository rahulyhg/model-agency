<?php

use yii\db\Migration;

/**
 * Class m180626_125104_create_tables_blog_module
 */
class m180626_125104_create_tables_blog_module extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
	    $this->createTable('{{%blog_category}}', [
		    'id' => $this->primaryKey(),
		    'title' => $this->string(255)->notNull(),
		    'slug' => $this->string(255)->notNull(),
		    'description' => $this->text(),
		    'thumbnail_id' => $this->integer(11),
		    'created_at' => $this->integer(11)->notNull(),
		    'updated_at' => $this->integer(11)->notNull()
	    ]);

	    $this->createTable('{{%blog_post}}', [
		    'id' => $this->primaryKey(),
		    'title' => $this->string(255)->notNull(),
		    'slug' => $this->string(255)->notNull(),
		    'content' => $this->text(),
		    'thumbnail_id' => $this->integer(11)->notNull(),
		    'created_at' => $this->integer(11)->notNull(),
		    'updated_at' => $this->integer(11)->notNull()
	    ]);

	    $this->createTable('{{%blog_post_category}}', [
		    'blog_post_id' => $this->integer(11)->notNull(),
		    'blog_category_id' => $this->integer(11)->notNull()
	    ]);

	    $this->addForeignKey('fk--blog_post_category--blog_post', '{{%blog_post_category}}', 'blog_post_id', '{{%blog_post}}', 'id');
	    $this->addForeignKey('fk--blog_post_category--blog_category', '{{%blog_post_category}}', 'blog_category_id', '{{%blog_category}}', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
	    $this->dropForeignKey( 'fk--blog_post_category--blog_post', '{{%blog_post_category}}' );
	    $this->dropForeignKey( 'fk--blog_post_category--blog_category', '{{%blog_post_category}}' );
	    $this->dropTable('{{%blog_post_category}}');
	    $this->dropTable('{{%blog_category}}');
	    $this->dropTable('{{%blog_post}}');
    }
}
