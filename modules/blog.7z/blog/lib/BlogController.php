<?php
namespace modules\blog\lib;

class BlogController extends \yii\web\Controller
{
}