<?php

namespace modules\blog\common\models;

use Yii;

/**
 * This is the model class for table "{{%blog_post_category}}".
 *
 * @property int $blog_post_id
 * @property int $blog_category_id
 *
 * @property Category $blogCategory
 * @property Post $blogPost
 */
class PostCategory extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%blog_post_category}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['blog_post_id', 'blog_category_id'], 'required'],
            [['blog_post_id', 'blog_category_id'], 'integer'],
            [['blog_category_id'], 'exist', 'skipOnError' => true, 'targetClass' => Category::class, 'targetAttribute' => ['blog_category_id' => 'id']],
            [['blog_post_id'], 'exist', 'skipOnError' => true, 'targetClass' => Post::class, 'targetAttribute' => ['blog_post_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'blog_post_id' => 'Blog Post ID',
            'blog_category_id' => 'Blog Category ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBlogCategory()
    {
        return $this->hasOne(Category::class, ['id' => 'blog_category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBlogPost()
    {
        return $this->hasOne(Post::class, ['id' => 'blog_post_id']);
    }
}
