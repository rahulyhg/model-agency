<?php

namespace modules\blog\common\models;

use common\behaviors\UploadFileBehavior;
use Yii;
use yii\behaviors\SluggableBehavior;
use yii\behaviors\TimestampBehavior;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

/**
 * This is the model class for table "{{%blog_post}}".
 *
 * @property int $id
 * @property string $title
 * @property string $content
 * @property int $thumbnail_id
 * @property int $created_at
 * @property int $updated_at
 * @property int $youtube_url
 *
 * @property PostCategory[] $blogPostCategories
 *
 * @property string $thumbnailUrl
 * @property string $thumbnailSize
 * @property string $permalink
 *
 * @property Post $prevModel
 * @property Post $nextModel
 */
class Post extends \yii\db\ActiveRecord {
	const THUMBNAILS_DIR = 'blog\thumbnails';
	public $deleteThumbnailFile = 0;
	public $thumbnailFile;

	private $thumbnailUrl;

	/**
	 * {@inheritdoc}
	 */
	public static function tableName() {
		return '{{%blog_post}}';
	}


	public function behaviors() {
		return ArrayHelper::merge( parent::behaviors(), [
			/*[
				'class'         => SluggableBehavior::class,
				'attribute'     => 'title',
				'slugAttribute' => 'slug',
				'ensureUnique'  => true,
				'immutable'     => true
			],*/
			[
				'class'              => TimestampBehavior::class,
				'createdAtAttribute' => 'created_at',
				'updatedAtAttribute' => 'updated_at'
			],
			[
				'class'     => UploadFileBehavior::class,
				'files'     => [
					[
						'fileAttribute'   => 'thumbnailFile',
						'idAttribute'     => 'thumbnail_id',
						'deleteAttribute' => 'deleteThumbnailFile',
					],
				],
				'directory' => self::THUMBNAILS_DIR,
			]
		] );
	}

	/**
	 * {@inheritdoc}
	 */
	public function rules() {
		return [
			[ [ 'title' ], 'required' ],
			[ [ 'content' ], 'string' ],
			[ [ 'thumbnail_id', 'created_at', 'updated_at' ], 'integer' ],
			[ [ 'title', 'youtube_url', /*'slug'*/ ], 'string', 'max' => 255 ],
			[ [ 'youtube_url' ], 'match', 'pattern' => '/^(http(s)?:\/\/)?((w){3}.)?youtu(be|.be)?(\.com)?\/.+/' ],
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function attributeLabels() {
		return [
			'id'            => 'ID',
			'title'         => 'Title',
			//'slug'         => 'Slug',
			'content'       => 'Content',
			'youtube_url'   => 'Youtube Video URL',
			'thumbnail_id'  => 'Thumbnail',
			'thumbnailFile' => 'Thumbnail',
			'created_at'    => 'Created At',
			'updated_at'    => 'Updated At',
		];
	}

	/**
	 * @return \yii\db\ActiveQuery
	 */
	public function getBlogPostCategories() {
		return $this->hasMany( PostCategory::class, [ 'blog_post_id' => 'id' ] );
	}

	/**
	 * @return mixed
	 */
	public function getThumbnailUrl() {
		if ( ! $this->thumbnailUrl ) {
			$this->thumbnailUrl = Yii::$app->filestorage->getFileUrl( $this->thumbnail_id );
			if ( ! $this->thumbnailUrl ) {
				$this->thumbnailUrl = Yii::$app->setting->get( 'blog', 'default_thumbnail' ) ?: null;
			}
		}

		return $this->thumbnailUrl;
	}

	public function getPermalink() {
		if ( $this->isNewRecord ) {
			return null;
		}

		return Url::to( [ '/blog/default/view', 'id' => $this->id ] );
	}

	protected $_prevModel = false;

	public function getPrevModel() {
		if ( $this->_prevModel !== false ) {
			return $this->_prevModel;
		}

		return $this->_prevModel = self::find()
		                               ->where( [ '<', 'created_at', $this->created_at ] )
		                               ->orderBy( 'created_at DESC' )
		                               ->one();
	}

	protected $_nextModel = false;

	public function getNextModel() {
		if ( $this->_nextModel !== false ) {
			return $this->_nextModel;
		}

		return $this->_nextModel = self::find()
		                               ->where( [ '>', 'created_at', $this->created_at ] )
		                               ->orderBy( 'created_at ASC' )
		                               ->one();
	}
}
