<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model common\modules\blog\models\Category */

$this->title                   = 'Create category';
$this->showTitle               = false;
$this->params['breadcrumbs'][] = [ 'label' => 'categories', 'url' => [ 'index' ] ];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="category-create">

	<?= $this->render( '_form', [
		'model' => $model,
	] ) ?>

</div>
