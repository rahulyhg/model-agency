<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\modules\blog\models\Category */

$this->title                   = 'Update category: ' . $model->title;
$this->showTitle               = false;
$this->params['breadcrumbs'][] = [ 'label' => 'categories', 'url' => [ 'index' ] ];
$this->params['breadcrumbs'][] = [ 'label' => $model->title, 'url' => [ 'view', 'id' => $model->id ] ];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="category-update">

	<?= $this->render( '_form', [
		'model' => $model,
	] ) ?>

</div>
