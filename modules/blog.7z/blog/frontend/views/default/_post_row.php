<?php
/**
 * @var $dataProvider ActiveDataProvider
 */
use yii\data\ActiveDataProvider;
use yii\helpers\Html;
use yii\helpers\StringHelper;

?>
<?php foreach($dataProvider->getModels() as $model) : ?>

<div class="b-new b-news__new">
  <a href="<?= $model->permalink ?>" class="b-new__img-link">
    <div class="b-new__img" style="background-image: url(<?= $model->getThumbnailUrl() ?>);"></div>
  </a>
  <div class="b-new__content">
    <div class="b-new__date"><span><?= Yii::$app->formatter->asDatetime($model->created_at) ?></span> <span>פורסם</span></div>
    <div class="b-new__text"><?= Html::a(StringHelper::truncate(strip_tags($model->content), 270, '', null), $model->permalink) ?></div>
    <div class="b-new__buttons">
      <a href="#" class="b-new__button">
        שתף
        <i class="fas fa-bullhorn"></i>
      </a>
    </div>
  </div>
</div>

<?php endforeach; ?>
