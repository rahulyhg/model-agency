<?php

/* @var $this yii\web\View */
/* @var $dataProvider ActiveDataProvider */
/* @var $query string */

use frontend\components\celeb\Celeb;
use yii\data\ActiveDataProvider;
use yii\helpers\HtmlPurifier;
use yii\helpers\Url;
use yii\widgets\ListView;

$this->title = 'Celeb';
$pageCount = (int)(($dataProvider->totalCount + $dataProvider->pagination->pageSize - 1) / $dataProvider->pagination->pageSize);
?>
<div class="b-news b-page__news">
  <div class="b-news-search__wrapper">
    <div class="b-news-search__header" dir="rtl">
      <div class="b-news-search__header-title">
        תוצאות חיפוש עבור:
        <?= $query ?>
      </div>
    </div>
    <?php if ($dataProvider->getTotalCount() <= 0) : ?>
      <div class="b-news-search__not-found">
        לא נמצא
      </div>
    <?php endif; ?>
  </div>

  <div id="loadmore-container" class="b-news__container">
  <?= $this->render('_post_row', ['dataProvider' => $dataProvider]) ?>
  </div>
  <?php if ($dataProvider->pagination->page + 1 < $pageCount) : ?>
    <div id="loadmore" class="b-news__load-more"><a class="b-button-gold">לטעון יותר</a></div>
    <?php
    $ajaxUrl = Url::to(['load-more', 'query' => $query]);
    $js = <<<JS
jQuery("#loadmore").tot_loadmore({
   containerSelector: "#loadmore-container",
   ajaxUrl: "$ajaxUrl"
});
JS;
    $this->registerJs($js);
    ?>
  <?php endif; ?>

</div>