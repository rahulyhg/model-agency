<?php
/**
 * @var $model modules\blog\common\models\Post
 */
use yii\helpers\Url;

?>
<div class="b-news-post b-page__news-post">
  <div class="b-news-post__wrapper">
    <div class="b-news-post__cover" style="background-image: url(<?= $model->getThumbnailUrl() ?>);">
      <div id="repost-fix" class="b-news-post__repost b-news-post__repost_center">
        <a href="#" class="b-news-post__repost-link">
          שתף
          <i class="fas fa-bullhorn"></i>
        </a>
      </div>
      <div class="b-news-post__repost b-news-post__repost_left">
        <a href="<?= Url::home() ?>" class="b-news-post__repost-link">
          חזור
          <i class="fas fa-arrow-circle-left"></i>
        </a>
      </div>
    </div>
    <div class="b-news-post__header">
      <div class="b-news-post__header-date">
        <span>פורסם</span>
        <span><?= Yii::$app->formatter->asTime($model->created_at, 'php:H:i:s') ?></span>
        <span><?= Yii::$app->formatter->asDate($model->created_at, 'php:d/m/Y') ?></span>
      </div>
    </div>
    <?= Yii::$app->block->post_before_content ?>
    <div class="b-news-post__content"><?= $model->content ?></div>
    <div class="b-new-post__share-btns">
		  <?= Yii::$app->block->post_share_buttons ?>
    </div>
    <div class="b-new-post__buttons">
      <?php if($model->prevModel) : ?>
        <div class="b-new-post__buttons-btn b-new-post__buttons-btn_prev buttons-btn-prev"><a href="<?= $model->prevModel->permalink ?>">חדשות קודמות</a></div>
      <?php endif; ?>
      <?php if($model->nextModel) : ?>
        <div class="b-new-post__buttons-btn b-new-post__buttons-btn_next buttons-btn-next"><a href="<?= $model->nextModel->permalink ?>">חדשות</a></div>
      <?php endif; ?>
      <div class="clear"></div>
    </div>
    <?= Yii::$app->block->post_before_content ?>
  </div>
  <?php echo \yii2mod\comments\widgets\Comment::widget([
    'model' => $model,
    'commentView' => '@modules/blog/widgets/comments/views/_comments'
  ]); ?>
</div>
<?php
$js = <<<JS
var elementPosition = $('#repost-fix').offset();
var oldElementCss = $('#repost-fix').css(['top', 'left', 'border-radius']);
$(window).scroll(function(){

        if($(window).scrollTop() > elementPosition.top){
              $('#repost-fix').css('position','fixed').css({"top": 0, "left": elementPosition.left + 70, "border-radius": "20px"});
        } else {
            $('#repost-fix').css('position','absolute').css(oldElementCss);
        }
});
JS;
$this->registerJs($js);
?>