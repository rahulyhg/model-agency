<?php

namespace modules\blog\frontend\controllers;

use modules\blog\common\models\Post;
use modules\blog\lib\BlogController;
use Yii;
use yii\data\ActiveDataProvider;
use yii\web\NotFoundHttpException;
use yii\web\Response;

class DefaultController extends BlogController
{

  public function actionSearch($query)
  {
    $dataProvider = new ActiveDataProvider([
      'query' => Post::find()->where(['like', 'content', $query])->orderBy('created_at DESC'),
      'pagination' => [
        'pageSize' => 9,
      ]
    ]);
    return $this->render('search', ['dataProvider' => $dataProvider, 'query' => $query]);
  }

  public function actionIndex()
  {
    $dataProvider = new ActiveDataProvider([
      'query' => Post::find()->orderBy('created_at DESC'),
      'pagination' => [
        'pageSize' => 9,
      ]
    ]);
    return $this->render('index', ['dataProvider' => $dataProvider]);
  }

  public function actionLoadMore()
  {
    if (is_numeric(Yii::$app->request->post('newPage'))) {
      $query = Post::find()->orderBy('created_at DESC');
      if($q = Yii::$app->request->get('query')){
        $query->andWhere([['like', 'content', $q]]);
      }
      $dataProvider = new ActiveDataProvider([
        'query' => $query,
        'pagination' => [
          'pageSize' => 9,
          'page' => Yii::$app->request->post('newPage'),
        ]
      ]);
      Yii::$app->response->format = Response::FORMAT_JSON;
      $newPage = $dataProvider->pagination->page + 1;
      return [
        'html' => $this->renderPartial('_post_row', ['dataProvider' => $dataProvider]),
        'isEnd' => $newPage >= $dataProvider->pagination->pageCount,
        'newPage' => $newPage,
        'totalPage' => $dataProvider->pagination->pageCount
      ];
    }
    throw new NotFoundHttpException();
  }

  public function actionView($id)
  {
    $model = $this->findModel($id);
    return $this->render('view', ['model' => $model]);
  }

  protected function findModel($id)
  {
    if (($model = Post::findOne($id))) {
      return $model;
    }
    throw new NotFoundHttpException('Post not found');
  }

    protected function findModelBySlug($slug)
    {
        if (($model = Post::findOne($slug))) {
            return $model;
        }
        throw new NotFoundHttpException('Post not found');
    }
}