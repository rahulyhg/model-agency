<?php

namespace modules\blog\widgets\comments\models;


use yii2mod\moderation\enums\Status;

class CommentModel extends \yii2mod\comments\models\CommentModel
{
  /**
   * @inheritdoc
   */
  public function rules()
  {
      return [
        [['entity', 'entityId'], 'required'],
        ['content', 'required', 'message' => \Yii::t('yii2mod.comments', 'Comment cannot be blank.')],
        [['content', 'entity', 'relatedTo', 'url'], 'string'],
        ['status', 'default', 'value' => Status::PENDING],
        ['status', 'in', 'range' => Status::getConstantsByName()],
        ['level', 'default', 'value' => 1],
        ['parentId', 'validateParentID'],
        [['entityId', 'parentId', 'status', 'level'], 'integer'],
      ];
  }

  public static function getTree($entity, $entityId, $maxLevel = null)
  {
    $query = static::find()
      ->alias('c')
      ->approved()
      ->andWhere([
        'c.entityId' => $entityId,
        'c.entity' => $entity,
      ])
      ->orderBy(['c.parentId' => SORT_ASC, 'c.createdAt' => SORT_DESC])
      ->with(['author']);

    if ($maxLevel > 0) {
      $query->andWhere(['<=', 'c.level', $maxLevel]);
    }

    $models = $query->all();

    if (!empty($models)) {
      $models = static::buildTree($models);
    }

    return $models;
  }

  /**
   * @return string
   */
  public function getPostedDate()
  {
    return \Yii::$app->formatter->asDatetime($this->createdAt, 'dd/MM/yy HH:mm:ss');
  }
}