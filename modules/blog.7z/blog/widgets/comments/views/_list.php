<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii2mod\editable\Editable;

/* @var $this \yii\web\View */
/* @var $model \yii2mod\comments\models\CommentModel */
/* @var $maxLevel null|integer comments max level */
?>

<div class="b-news-post__comments-item" id="comment-<?php echo $model->id; ?>">
    <div class="b-news-post__comments-item-header">
        <div class="b-news-post__comments-item-title"><?= $model->getAuthorName(); ?></div>
        <div class="b-news-post__comments-item-date"><?= $model->getPostedDate() ?></div>
    </div>
    <div class="b-news-post__comments-item-text"><?= $model->getContent() ?></div>
</div>