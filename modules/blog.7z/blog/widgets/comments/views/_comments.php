<?php

use yii\helpers\ArrayHelper;
use yii\widgets\ListView;
use yii\widgets\Pjax;

/* @var $this \yii\web\View */
/* @var $commentModel \yii2mod\comments\models\CommentModel */
/* @var $maxLevel null|integer comments max level */
/* @var $encryptedEntity string */
/* @var $pjaxContainerId string */
/* @var $formId string comment form id */
/* @var $commentDataProvider \yii\data\ArrayDataProvider */
/* @var $listViewConfig array */
/* @var $commentWrapperId string */
?>

<div class="b-news-post__comments" id="<?php echo $commentWrapperId; ?>">
  <?php $js= <<<JS
  //fix submit duplicating
var totDisableSubmitBtn = false;
function totDisableSubmitBtnInit(){
  jQuery('form.disable-submit-btn').on('beforeSubmit', function (e) {
    if(totDisableSubmitBtn === undefined || totDisableSubmitBtn === false){
      return totDisableSubmitBtn = true;
    }
    return false;
  });
}
$(document).on('ready pjax:success', function(){
    totDisableSubmitBtnInit();
});
$(document).on('ready pjax:complete', function(){
    totDisableSubmitBtn = false;
});
totDisableSubmitBtnInit();
JS;
  $this->registerJs($js) ?>
  <?php Pjax::begin(['enablePushState' => false, 'timeout' => 20000, 'id' => $pjaxContainerId]); ?>
  <div class="b-news-post__comments-title">
    תגובות
  </div>
  <?php if (!Yii::$app->user->isGuest) : ?>
    <?php echo $this->render('_form', [
      'commentModel' => $commentModel,
      'formId' => $formId,
      'encryptedEntity' => $encryptedEntity,
    ]); ?>
  <?php endif; ?>

    <?php echo ListView::widget(ArrayHelper::merge(
      [
        'dataProvider' => $commentDataProvider,
        'layout' => "{items}\n{pager}",
        'itemView' => '_list',
        'viewParams' => [
          'maxLevel' => $maxLevel,
        ],
        'options' => [
          'tag' => 'div',
          'class' => 'b-news-post__comments-items',
        ],
        'itemOptions' => [
          'tag' => false,
        ],
      ],
      $listViewConfig
    )); ?>
  <?php Pjax::end(); ?>
</div>