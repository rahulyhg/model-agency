<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/* @var $this \yii\web\View */
/* @var $commentModel \yii2mod\comments\models\CommentModel */
/* @var $encryptedEntity string */
/* @var $formId string comment form id */
?>
<?php $form = ActiveForm::begin([
  'options' => [
    'id' => $formId,
    'class' => 'disable-submit-btn'
  ],
  'action' => Url::to(['/comment/default/create', 'entity' => $encryptedEntity]),
  'validateOnChange' => false,
  'validateOnBlur' => false,
]); ?>
<div class="b-news-post__form">

  <?php //echo $form->field($commentModel, 'content', ['template' => '{input}{error}'])->textInput(['placeholder' => 'שֵׁם']) ?>
  <?php echo $form->field($commentModel, 'content', ['template' => '{input}'])->textarea(['placeholder' => 'הוֹדָעָה', 'rows' => 10, 'cols' => 30]) ?>
  <?php echo Html::input('submit', null, 'שלח', ['id' => 'form-comment-submit']); ?>

</div>
<?php $form->end(); ?>
